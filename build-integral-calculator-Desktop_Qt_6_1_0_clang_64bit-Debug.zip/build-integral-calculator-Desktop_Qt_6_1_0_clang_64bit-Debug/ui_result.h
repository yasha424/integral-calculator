/********************************************************************************
** Form generated from reading UI file 'result.ui'
**
** Created by: Qt User Interface Compiler version 6.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULT_H
#define UI_RESULT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <qcustomplot.h>

QT_BEGIN_NAMESPACE

class Ui_Result
{
public:
    QCustomPlot *graphic;
    QLabel *label;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *lower;
    QLabel *upper;
    QLabel *integral;
    QPushButton *pushButton;
    QLabel *depth;
    QLabel *divided;

    void setupUi(QDialog *Result)
    {
        if (Result->objectName().isEmpty())
            Result->setObjectName(QString::fromUtf8("Result"));
        Result->resize(630, 340);
        Result->setMinimumSize(QSize(630, 340));
        Result->setMaximumSize(QSize(630, 340));
        Result->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        graphic = new QCustomPlot(Result);
        graphic->setObjectName(QString::fromUtf8("graphic"));
        graphic->setGeometry(QRect(10, 20, 300, 300));
        graphic->setCursor(QCursor(Qt::PointingHandCursor));
        graphic->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-radius: 15px;"));
        label = new QLabel(Result);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(320, 20, 300, 300));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 93, 95);\n"
"border-radius: 15px;\n"
"\n"
""));
        label_3 = new QLabel(Result);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(340, 50, 260, 60));
        label_3->setStyleSheet(QString::fromUtf8("border-radius: 6px;\n"
"background-color: rgb(0,0,0);\n"
"border-style:inset;"));
        label_3->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_2 = new QLabel(Result);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(340, 65, 30, 30));
        label_2->setPixmap(QPixmap(QString::fromUtf8("images/integral-white.png")));
        label_2->setScaledContents(true);
        lower = new QLabel(Result);
        lower->setObjectName(QString::fromUtf8("lower"));
        lower->setGeometry(QRect(344, 94, 29, 16));
        QFont font;
        font.setPointSize(9);
        lower->setFont(font);
        lower->setCursor(QCursor(Qt::IBeamCursor));
        lower->setStyleSheet(QString::fromUtf8("color: white;"));
        lower->setAlignment(Qt::AlignCenter);
        lower->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        upper = new QLabel(Result);
        upper->setObjectName(QString::fromUtf8("upper"));
        upper->setGeometry(QRect(345, 50, 29, 16));
        upper->setFont(font);
        upper->setCursor(QCursor(Qt::IBeamCursor));
        upper->setStyleSheet(QString::fromUtf8("color: white;"));
        upper->setAlignment(Qt::AlignCenter);
        upper->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        integral = new QLabel(Result);
        integral->setObjectName(QString::fromUtf8("integral"));
        integral->setGeometry(QRect(370, 60, 221, 41));
        integral->setCursor(QCursor(Qt::IBeamCursor));
        integral->setStyleSheet(QString::fromUtf8("color: white;"));
        integral->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        pushButton = new QPushButton(Result);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(360, 260, 220, 30));
        pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 129, 0);\n"
"border-radius: 6px;\n"
"color: white;"));
        depth = new QLabel(Result);
        depth->setObjectName(QString::fromUtf8("depth"));
        depth->setGeometry(QRect(340, 120, 260, 50));
        QFont font1;
        font1.setPointSize(11);
        depth->setFont(font1);
        depth->setCursor(QCursor(Qt::IBeamCursor));
        depth->setStyleSheet(QString::fromUtf8("border-radius: 6px;\n"
"background-color: rgb(0,0,0);\n"
"border-style:inset;\n"
"color: white;"));
        depth->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        depth->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        divided = new QLabel(Result);
        divided->setObjectName(QString::fromUtf8("divided"));
        divided->setGeometry(QRect(340, 180, 260, 50));
        divided->setFont(font1);
        divided->setCursor(QCursor(Qt::IBeamCursor));
        divided->setStyleSheet(QString::fromUtf8("border-radius: 6px;\n"
"background-color: rgb(0,0,0);\n"
"border-style:inset;\n"
"color: white;"));
        divided->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        divided->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        label->raise();
        label_3->raise();
        label_2->raise();
        lower->raise();
        upper->raise();
        integral->raise();
        pushButton->raise();
        depth->raise();
        divided->raise();
        graphic->raise();

        retranslateUi(Result);

        QMetaObject::connectSlotsByName(Result);
    } // setupUi

    void retranslateUi(QDialog *Result)
    {
        Result->setWindowTitle(QCoreApplication::translate("Result", "Dialog", nullptr));
        label->setText(QString());
        label_3->setText(QString());
        label_2->setText(QString());
        lower->setText(QString());
        upper->setText(QString());
        integral->setText(QString());
        pushButton->setText(QCoreApplication::translate("Result", "\320\227\320\261\320\265\321\200\320\265\320\263\321\202\320\270 \321\200\320\265\320\267\321\203\320\273\321\214\321\202\320\260\321\202 \321\203 \321\204\320\260\320\271\320\273", nullptr));
        depth->setText(QString());
        divided->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Result: public Ui_Result {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULT_H
