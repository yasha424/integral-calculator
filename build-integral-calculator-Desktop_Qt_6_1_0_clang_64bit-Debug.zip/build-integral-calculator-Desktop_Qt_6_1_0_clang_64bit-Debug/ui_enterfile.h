/********************************************************************************
** Form generated from reading UI file 'enterfile.ui'
**
** Created by: Qt User Interface Compiler version 6.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENTERFILE_H
#define UI_ENTERFILE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_EnterFile
{
public:
    QLineEdit *line;
    QLabel *label;
    QPushButton *pushButton;

    void setupUi(QDialog *EnterFile)
    {
        if (EnterFile->objectName().isEmpty())
            EnterFile->setObjectName(QString::fromUtf8("EnterFile"));
        EnterFile->resize(400, 105);
        EnterFile->setMinimumSize(QSize(400, 105));
        EnterFile->setMaximumSize(QSize(400, 105));
        EnterFile->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        line = new QLineEdit(EnterFile);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(10, 30, 380, 30));
        line->setStyleSheet(QString::fromUtf8("background-color: rgb(38, 36, 36);\n"
"border-radius: 8px;\n"
"color: white;"));
        label = new QLabel(EnterFile);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 5, 380, 25));
        QFont font;
        font.setPointSize(12);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color: white;"));
        label->setAlignment(Qt::AlignCenter);
        pushButton = new QPushButton(EnterFile);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(170, 65, 80, 30));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 125, 0);\n"
"border-radius: 7px;\n"
"color: white;"));

        retranslateUi(EnterFile);

        QMetaObject::connectSlotsByName(EnterFile);
    } // setupUi

    void retranslateUi(QDialog *EnterFile)
    {
        EnterFile->setWindowTitle(QCoreApplication::translate("EnterFile", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("EnterFile", "\320\221\321\203\320\264\321\214 \320\273\320\260\321\201\320\272\320\260, \320\262\320\262\320\265\320\264\321\226\321\202\321\214 \321\226\320\274'\321\217 \321\204\320\260\320\271\320\273\321\203 \320\267 \321\217\320\272\320\276\320\263\320\276 \321\205\320\276\321\207\320\265\321\202\320\265 \320\267\321\207\320\270\321\202\320\260\321\202\320\270 \321\200\321\226\320\262\320\275\321\217\320\275\320\275\321\217", nullptr));
        pushButton->setText(QCoreApplication::translate("EnterFile", "\320\225\320\275\321\202\320\265\321\200", nullptr));
    } // retranslateUi

};

namespace Ui {
    class EnterFile: public Ui_EnterFile {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENTERFILE_H
