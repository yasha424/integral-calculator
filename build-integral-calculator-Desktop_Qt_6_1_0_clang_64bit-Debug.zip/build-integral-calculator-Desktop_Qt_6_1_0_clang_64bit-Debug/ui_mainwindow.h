/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *zero;
    QPushButton *dot;
    QPushButton *equal;
    QPushButton *six;
    QPushButton *five;
    QPushButton *four;
    QPushButton *three;
    QPushButton *two;
    QPushButton *one;
    QPushButton *nine;
    QPushButton *eight;
    QPushButton *seven;
    QPushButton *mult;
    QPushButton *minus;
    QPushButton *plus;
    QPushButton *divide;
    QPushButton *closeBracket;
    QPushButton *openBracket;
    QPushButton *clear;
    QLabel *label;
    QPushButton *delet;
    QPushButton *pi;
    QPushButton *x_but;
    QPushButton *pow;
    QLabel *integral_sign;
    QLineEdit *lower_bound;
    QLineEdit *upper_bound;
    QPushButton *clear_2;
    QLabel *label_2;
    QComboBox *choose;
    QPushButton *file;
    QStatusBar *statusbar;
    QButtonGroup *buttonGroup_2;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(360, 500);
        MainWindow->setMinimumSize(QSize(360, 500));
        MainWindow->setMaximumSize(QSize(360, 500));
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
""));
        MainWindow->setTabShape(QTabWidget::Rounded);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        zero = new QPushButton(centralwidget);
        buttonGroup_2 = new QButtonGroup(MainWindow);
        buttonGroup_2->setObjectName(QString::fromUtf8("buttonGroup_2"));
        buttonGroup_2->addButton(zero);
        zero->setObjectName(QString::fromUtf8("zero"));
        zero->setGeometry(QRect(10, 410, 130, 60));
        QFont font;
        font.setPointSize(24);
        zero->setFont(font);
        zero->setCursor(QCursor(Qt::PointingHandCursor));
        zero->setMouseTracking(true);
        zero->setTabletTracking(true);
        zero->setFocusPolicy(Qt::NoFocus);
        zero->setAutoFillBackground(false);
        zero->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        dot = new QPushButton(centralwidget);
        buttonGroup_2->addButton(dot);
        dot->setObjectName(QString::fromUtf8("dot"));
        dot->setGeometry(QRect(150, 410, 60, 60));
        dot->setFont(font);
        dot->setCursor(QCursor(Qt::PointingHandCursor));
        dot->setMouseTracking(true);
        dot->setTabletTracking(true);
        dot->setFocusPolicy(Qt::NoFocus);
        dot->setAutoFillBackground(false);
        dot->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        equal = new QPushButton(centralwidget);
        buttonGroup_2->addButton(equal);
        equal->setObjectName(QString::fromUtf8("equal"));
        equal->setGeometry(QRect(220, 410, 61, 61));
        equal->setFont(font);
        equal->setCursor(QCursor(Qt::PointingHandCursor));
        equal->setMouseTracking(true);
        equal->setTabletTracking(true);
        equal->setFocusPolicy(Qt::NoFocus);
        equal->setLayoutDirection(Qt::LeftToRight);
        equal->setAutoFillBackground(false);
        equal->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 159, 12);\n"
"border-radius: 14px;\n"
"color: white;"));
        six = new QPushButton(centralwidget);
        buttonGroup_2->addButton(six);
        six->setObjectName(QString::fromUtf8("six"));
        six->setGeometry(QRect(150, 270, 60, 60));
        six->setFont(font);
        six->setCursor(QCursor(Qt::PointingHandCursor));
        six->setMouseTracking(true);
        six->setTabletTracking(true);
        six->setFocusPolicy(Qt::NoFocus);
        six->setAutoFillBackground(false);
        six->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        five = new QPushButton(centralwidget);
        buttonGroup_2->addButton(five);
        five->setObjectName(QString::fromUtf8("five"));
        five->setGeometry(QRect(80, 270, 60, 60));
        five->setFont(font);
        five->setCursor(QCursor(Qt::PointingHandCursor));
        five->setMouseTracking(true);
        five->setTabletTracking(true);
        five->setFocusPolicy(Qt::NoFocus);
        five->setAutoFillBackground(false);
        five->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        four = new QPushButton(centralwidget);
        buttonGroup_2->addButton(four);
        four->setObjectName(QString::fromUtf8("four"));
        four->setGeometry(QRect(10, 270, 60, 60));
        four->setFont(font);
        four->setCursor(QCursor(Qt::PointingHandCursor));
        four->setMouseTracking(true);
        four->setTabletTracking(true);
        four->setFocusPolicy(Qt::NoFocus);
        four->setAutoFillBackground(false);
        four->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        three = new QPushButton(centralwidget);
        buttonGroup_2->addButton(three);
        three->setObjectName(QString::fromUtf8("three"));
        three->setGeometry(QRect(150, 340, 60, 60));
        three->setFont(font);
        three->setCursor(QCursor(Qt::PointingHandCursor));
        three->setMouseTracking(true);
        three->setTabletTracking(true);
        three->setFocusPolicy(Qt::NoFocus);
        three->setAutoFillBackground(false);
        three->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        two = new QPushButton(centralwidget);
        buttonGroup_2->addButton(two);
        two->setObjectName(QString::fromUtf8("two"));
        two->setGeometry(QRect(80, 340, 60, 60));
        two->setFont(font);
        two->setCursor(QCursor(Qt::PointingHandCursor));
        two->setMouseTracking(true);
        two->setTabletTracking(true);
        two->setFocusPolicy(Qt::NoFocus);
        two->setAutoFillBackground(false);
        two->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        one = new QPushButton(centralwidget);
        buttonGroup_2->addButton(one);
        one->setObjectName(QString::fromUtf8("one"));
        one->setGeometry(QRect(10, 340, 60, 60));
        one->setFont(font);
        one->setCursor(QCursor(Qt::PointingHandCursor));
        one->setMouseTracking(true);
        one->setTabletTracking(true);
        one->setFocusPolicy(Qt::NoFocus);
        one->setAutoFillBackground(false);
        one->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        nine = new QPushButton(centralwidget);
        buttonGroup_2->addButton(nine);
        nine->setObjectName(QString::fromUtf8("nine"));
        nine->setGeometry(QRect(150, 200, 60, 60));
        nine->setFont(font);
        nine->setCursor(QCursor(Qt::PointingHandCursor));
        nine->setMouseTracking(true);
        nine->setTabletTracking(true);
        nine->setFocusPolicy(Qt::NoFocus);
        nine->setAutoFillBackground(false);
        nine->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        eight = new QPushButton(centralwidget);
        buttonGroup_2->addButton(eight);
        eight->setObjectName(QString::fromUtf8("eight"));
        eight->setGeometry(QRect(80, 200, 60, 60));
        eight->setFont(font);
        eight->setCursor(QCursor(Qt::PointingHandCursor));
        eight->setMouseTracking(true);
        eight->setTabletTracking(true);
        eight->setFocusPolicy(Qt::NoFocus);
        eight->setAutoFillBackground(false);
        eight->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        seven = new QPushButton(centralwidget);
        buttonGroup_2->addButton(seven);
        seven->setObjectName(QString::fromUtf8("seven"));
        seven->setGeometry(QRect(10, 200, 60, 60));
        seven->setFont(font);
        seven->setCursor(QCursor(Qt::PointingHandCursor));
        seven->setMouseTracking(true);
        seven->setTabletTracking(true);
        seven->setFocusPolicy(Qt::NoFocus);
        seven->setAutoFillBackground(false);
        seven->setStyleSheet(QString::fromUtf8("background-color: rgb(57, 57, 57);\n"
"border-radius: 14px;\n"
"color: white;"));
        mult = new QPushButton(centralwidget);
        buttonGroup_2->addButton(mult);
        mult->setObjectName(QString::fromUtf8("mult"));
        mult->setGeometry(QRect(220, 130, 60, 60));
        mult->setFont(font);
        mult->setCursor(QCursor(Qt::PointingHandCursor));
        mult->setMouseTracking(false);
        mult->setTabletTracking(false);
        mult->setFocusPolicy(Qt::NoFocus);
        mult->setAutoFillBackground(false);
        mult->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 159, 12);\n"
"border-radius: 14px;\n"
"color: white;"));
        mult->setAutoDefault(true);
        mult->setFlat(false);
        minus = new QPushButton(centralwidget);
        buttonGroup_2->addButton(minus);
        minus->setObjectName(QString::fromUtf8("minus"));
        minus->setGeometry(QRect(220, 270, 60, 60));
        minus->setFont(font);
        minus->setCursor(QCursor(Qt::PointingHandCursor));
        minus->setMouseTracking(true);
        minus->setTabletTracking(true);
        minus->setFocusPolicy(Qt::NoFocus);
        minus->setAutoFillBackground(false);
        minus->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 159, 12);\n"
"border-radius: 14px;\n"
"color: white;"));
        plus = new QPushButton(centralwidget);
        buttonGroup_2->addButton(plus);
        plus->setObjectName(QString::fromUtf8("plus"));
        plus->setGeometry(QRect(220, 340, 60, 60));
        plus->setFont(font);
        plus->setCursor(QCursor(Qt::PointingHandCursor));
        plus->setMouseTracking(true);
        plus->setTabletTracking(true);
        plus->setFocusPolicy(Qt::NoFocus);
        plus->setAutoFillBackground(false);
        plus->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 159, 12);\n"
"border-radius: 14px;\n"
"color: white;"));
        divide = new QPushButton(centralwidget);
        buttonGroup_2->addButton(divide);
        divide->setObjectName(QString::fromUtf8("divide"));
        divide->setGeometry(QRect(220, 200, 60, 60));
        divide->setFont(font);
        divide->setCursor(QCursor(Qt::PointingHandCursor));
        divide->setMouseTracking(true);
        divide->setTabletTracking(true);
        divide->setFocusPolicy(Qt::NoFocus);
        divide->setAutoFillBackground(false);
        divide->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 159, 12);\n"
"border-radius: 14px;\n"
"color: white;"));
        closeBracket = new QPushButton(centralwidget);
        buttonGroup_2->addButton(closeBracket);
        closeBracket->setObjectName(QString::fromUtf8("closeBracket"));
        closeBracket->setGeometry(QRect(150, 130, 60, 60));
        closeBracket->setFont(font);
        closeBracket->setCursor(QCursor(Qt::PointingHandCursor));
        closeBracket->setMouseTracking(true);
        closeBracket->setTabletTracking(true);
        closeBracket->setFocusPolicy(Qt::NoFocus);
        closeBracket->setAutoFillBackground(false);
        closeBracket->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 93, 95);\n"
"border-radius: 14px;\n"
"color: white;"));
        openBracket = new QPushButton(centralwidget);
        buttonGroup_2->addButton(openBracket);
        openBracket->setObjectName(QString::fromUtf8("openBracket"));
        openBracket->setGeometry(QRect(80, 130, 60, 60));
        openBracket->setFont(font);
        openBracket->setCursor(QCursor(Qt::PointingHandCursor));
        openBracket->setMouseTracking(true);
        openBracket->setTabletTracking(true);
        openBracket->setFocusPolicy(Qt::NoFocus);
        openBracket->setAutoFillBackground(false);
        openBracket->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 93, 95);\n"
"border-radius: 14px;\n"
"color: white;"));
        clear = new QPushButton(centralwidget);
        buttonGroup_2->addButton(clear);
        clear->setObjectName(QString::fromUtf8("clear"));
        clear->setGeometry(QRect(10, 130, 60, 60));
        clear->setFont(font);
        clear->setCursor(QCursor(Qt::PointingHandCursor));
        clear->setMouseTracking(true);
        clear->setTabletTracking(true);
        clear->setFocusPolicy(Qt::NoFocus);
        clear->setAutoFillBackground(false);
        clear->setStyleSheet(QString::fromUtf8("background-color: rgb(89, 93, 95);\n"
"border-radius: 14px;\n"
"color: white;"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 10, 301, 70));
        QFont font1;
        font1.setPointSize(22);
        label->setFont(font1);
        label->setCursor(QCursor(Qt::IBeamCursor));
        label->setMouseTracking(true);
        label->setTabletTracking(true);
        label->setLayoutDirection(Qt::RightToLeft);
        label->setAutoFillBackground(false);
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(38, 36, 36);\n"
"border-radius: 14px;\n"
"color: white;"));
        label->setScaledContents(false);
        label->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        delet = new QPushButton(centralwidget);
        buttonGroup_2->addButton(delet);
        delet->setObjectName(QString::fromUtf8("delet"));
        delet->setGeometry(QRect(290, 410, 60, 60));
        delet->setFont(font);
        delet->setCursor(QCursor(Qt::PointingHandCursor));
        delet->setMouseTracking(true);
        delet->setTabletTracking(true);
        delet->setFocusPolicy(Qt::NoFocus);
        delet->setAutoFillBackground(false);
        delet->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 159, 12);\n"
"border-radius: 14px;\n"
"color: white;"));
        pi = new QPushButton(centralwidget);
        pi->setObjectName(QString::fromUtf8("pi"));
        pi->setGeometry(QRect(290, 340, 60, 60));
        pi->setFont(font);
        pi->setCursor(QCursor(Qt::PointingHandCursor));
        pi->setMouseTracking(true);
        pi->setTabletTracking(true);
        pi->setFocusPolicy(Qt::NoFocus);
        pi->setAutoFillBackground(false);
        pi->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 159, 12);\n"
"border-radius: 14px;\n"
"color: white;"));
        x_but = new QPushButton(centralwidget);
        x_but->setObjectName(QString::fromUtf8("x_but"));
        x_but->setGeometry(QRect(290, 200, 60, 60));
        x_but->setFont(font);
        x_but->setCursor(QCursor(Qt::PointingHandCursor));
        x_but->setMouseTracking(true);
        x_but->setTabletTracking(true);
        x_but->setFocusPolicy(Qt::NoFocus);
        x_but->setAutoFillBackground(false);
        x_but->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 159, 12);\n"
"border-radius: 14px;\n"
"color: white;"));
        pow = new QPushButton(centralwidget);
        pow->setObjectName(QString::fromUtf8("pow"));
        pow->setGeometry(QRect(290, 270, 60, 60));
        pow->setFont(font);
        pow->setCursor(QCursor(Qt::PointingHandCursor));
        pow->setMouseTracking(true);
        pow->setTabletTracking(true);
        pow->setFocusPolicy(Qt::NoFocus);
        pow->setAutoFillBackground(false);
        pow->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 159, 12);\n"
"border-radius: 14px;\n"
"color: white;"));
        integral_sign = new QLabel(centralwidget);
        integral_sign->setObjectName(QString::fromUtf8("integral_sign"));
        integral_sign->setGeometry(QRect(12, 27, 27, 38));
        integral_sign->setStyleSheet(QString::fromUtf8("background-color: rgb(38, 36, 36);\n"
"border-radius: 14px;\n"
""));
        integral_sign->setPixmap(QPixmap(QString::fromUtf8("images/integral-white.png")));
        integral_sign->setScaledContents(true);
        integral_sign->setWordWrap(false);
        lower_bound = new QLineEdit(centralwidget);
        lower_bound->setObjectName(QString::fromUtf8("lower_bound"));
        lower_bound->setGeometry(QRect(15, 64, 27, 14));
        QFont font2;
        font2.setPointSize(8);
        lower_bound->setFont(font2);
        lower_bound->setStyleSheet(QString::fromUtf8("border-radius: 4px;\n"
"background-color: rgb(38, 36, 36);\n"
"border-width: 2px;\n"
"border-color: rgb(0,0,0);\n"
"border-style:inset;\n"
"color: white;"));
        lower_bound->setAlignment(Qt::AlignCenter);
        upper_bound = new QLineEdit(centralwidget);
        upper_bound->setObjectName(QString::fromUtf8("upper_bound"));
        upper_bound->setGeometry(QRect(15, 12, 27, 14));
        upper_bound->setFont(font2);
        upper_bound->setStyleSheet(QString::fromUtf8("border-radius: 4px;\n"
"background-color: rgb(38, 36, 36);\n"
"border-width: 2px;\n"
"border-color: rgb(0,0,0);\n"
"border-style:inset;\n"
"color: white;"));
        upper_bound->setAlignment(Qt::AlignCenter);
        clear_2 = new QPushButton(centralwidget);
        clear_2->setObjectName(QString::fromUtf8("clear_2"));
        clear_2->setGeometry(QRect(290, 130, 60, 60));
        clear_2->setFont(font);
        clear_2->setCursor(QCursor(Qt::PointingHandCursor));
        clear_2->setMouseTracking(true);
        clear_2->setTabletTracking(true);
        clear_2->setFocusPolicy(Qt::NoFocus);
        clear_2->setAutoFillBackground(false);
        clear_2->setStyleSheet(QString::fromUtf8("background-color: rgb(88, 92, 94);\n"
"border-radius: 14px;\n"
"color: white;"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 10, 340, 70));
        label_2->setFont(font);
        label_2->setMouseTracking(true);
        label_2->setTabletTracking(true);
        label_2->setLayoutDirection(Qt::RightToLeft);
        label_2->setAutoFillBackground(false);
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(38, 36, 36);\n"
"border-radius: 14px;\n"
"padding: 22px;"));
        label_2->setScaledContents(false);
        label_2->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);
        choose = new QComboBox(centralwidget);
        choose->addItem(QString());
        choose->addItem(QString());
        choose->addItem(QString());
        choose->setObjectName(QString::fromUtf8("choose"));
        choose->setGeometry(QRect(10, 90, 340, 30));
        choose->setCursor(QCursor(Qt::PointingHandCursor));
        choose->setAcceptDrops(false);
        choose->setStyleSheet(QString::fromUtf8("border-radius: 9px;\n"
"background-color: rgb(38, 36, 36);\n"
"border-style:inset;\n"
"padding: 5px;\n"
""));
        choose->setMaxVisibleItems(10);
        choose->setIconSize(QSize(16, 16));
        choose->setDuplicatesEnabled(false);
        file = new QPushButton(centralwidget);
        file->setObjectName(QString::fromUtf8("file"));
        file->setGeometry(QRect(316, 14, 30, 15));
        file->setCursor(QCursor(Qt::PointingHandCursor));
        file->setStyleSheet(QString::fromUtf8("border-radius: 5px;\n"
"border-color: rgb(88, 92, 94);\n"
"border-width: 1px;\n"
"border-style:inset;\n"
"color: white;\n"
""));
        MainWindow->setCentralWidget(centralwidget);
        label_2->raise();
        zero->raise();
        dot->raise();
        equal->raise();
        six->raise();
        five->raise();
        four->raise();
        three->raise();
        two->raise();
        one->raise();
        nine->raise();
        eight->raise();
        seven->raise();
        mult->raise();
        minus->raise();
        plus->raise();
        divide->raise();
        closeBracket->raise();
        openBracket->raise();
        clear->raise();
        label->raise();
        delet->raise();
        pi->raise();
        x_but->raise();
        pow->raise();
        integral_sign->raise();
        lower_bound->raise();
        upper_bound->raise();
        clear_2->raise();
        choose->raise();
        file->raise();
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        zero->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        dot->setText(QCoreApplication::translate("MainWindow", ".", nullptr));
        equal->setText(QCoreApplication::translate("MainWindow", "=", nullptr));
        six->setText(QCoreApplication::translate("MainWindow", "6", nullptr));
        five->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        four->setText(QCoreApplication::translate("MainWindow", "4", nullptr));
        three->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        two->setText(QCoreApplication::translate("MainWindow", "2", nullptr));
        one->setText(QCoreApplication::translate("MainWindow", "1", nullptr));
        nine->setText(QCoreApplication::translate("MainWindow", "9", nullptr));
        eight->setText(QCoreApplication::translate("MainWindow", "8", nullptr));
        seven->setText(QCoreApplication::translate("MainWindow", "7", nullptr));
        mult->setText(QCoreApplication::translate("MainWindow", "*", nullptr));
        minus->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        plus->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        divide->setText(QCoreApplication::translate("MainWindow", "/", nullptr));
        closeBracket->setText(QCoreApplication::translate("MainWindow", ")", nullptr));
        openBracket->setText(QCoreApplication::translate("MainWindow", "(", nullptr));
        clear->setText(QCoreApplication::translate("MainWindow", "C", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        delet->setText(QCoreApplication::translate("MainWindow", "\342\214\253", nullptr));
        pi->setText(QCoreApplication::translate("MainWindow", "pi", nullptr));
        x_but->setText(QCoreApplication::translate("MainWindow", "X", nullptr));
        pow->setText(QCoreApplication::translate("MainWindow", "^", nullptr));
        integral_sign->setText(QString());
        clear_2->setText(QCoreApplication::translate("MainWindow", "AC", nullptr));
        label_2->setText(QString());
        choose->setItemText(0, QCoreApplication::translate("MainWindow", "\320\234\320\265\321\202\320\276\320\264 \320\277\321\200\321\217\320\274\320\276\320\272\321\203\321\202\320\275\320\270\320\272\321\226\320\262", nullptr));
        choose->setItemText(1, QCoreApplication::translate("MainWindow", "\320\234\320\265\321\202\320\276\320\264 \321\202\321\200\320\260\320\277\320\265\321\206\321\226\320\271", nullptr));
        choose->setItemText(2, QCoreApplication::translate("MainWindow", "\320\234\320\265\321\202\320\276\320\264 \320\241\321\226\320\274\320\277\321\201\320\276\320\275\320\260", nullptr));

        file->setText(QCoreApplication::translate("MainWindow", "\342\200\242\342\200\242\342\200\242", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
