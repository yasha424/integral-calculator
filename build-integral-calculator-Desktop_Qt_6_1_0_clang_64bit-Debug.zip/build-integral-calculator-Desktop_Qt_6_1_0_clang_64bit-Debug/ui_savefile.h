/********************************************************************************
** Form generated from reading UI file 'savefile.ui'
**
** Created by: Qt User Interface Compiler version 6.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SAVEFILE_H
#define UI_SAVEFILE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_saveFile
{
public:
    QLineEdit *line;
    QPushButton *pushButton;
    QLabel *label;

    void setupUi(QDialog *saveFile)
    {
        if (saveFile->objectName().isEmpty())
            saveFile->setObjectName(QString::fromUtf8("saveFile"));
        saveFile->resize(400, 105);
        saveFile->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        line = new QLineEdit(saveFile);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(10, 30, 380, 30));
        line->setStyleSheet(QString::fromUtf8("background-color: rgb(38, 36, 36);\n"
"border-radius: 8px;\n"
"color: white;"));
        pushButton = new QPushButton(saveFile);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(170, 65, 80, 30));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 125, 0);\n"
"border-radius: 7px;\n"
"color: white;"));
        label = new QLabel(saveFile);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 5, 380, 25));
        QFont font;
        font.setPointSize(12);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color: white;"));
        label->setAlignment(Qt::AlignCenter);

        retranslateUi(saveFile);

        QMetaObject::connectSlotsByName(saveFile);
    } // setupUi

    void retranslateUi(QDialog *saveFile)
    {
        saveFile->setWindowTitle(QCoreApplication::translate("saveFile", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("saveFile", "\320\225\320\275\321\202\320\265\321\200", nullptr));
        label->setText(QCoreApplication::translate("saveFile", "\320\221\321\203\320\264\321\214 \320\273\320\260\321\201\320\272\320\260, \320\262\320\262\320\265\320\264\321\226\321\202\321\214 \321\226\320\274'\321\217 \321\204\320\260\320\271\320\273\321\203,  \320\272\321\203\320\264\320\270 \321\205\320\276\321\207\320\265\321\202\320\265 \320\267\320\261\320\265\321\200\320\265\320\263\321\202\320\270 \321\200\320\265\320\267\321\203\320\273\321\214\321\202\320\260\321\202", nullptr));
    } // retranslateUi

};

namespace Ui {
    class saveFile: public Ui_saveFile {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SAVEFILE_H
